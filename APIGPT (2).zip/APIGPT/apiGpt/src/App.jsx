import CompAPi from "./components/CompAPi";

import React from 'react'

function App() {
  return (
    <CompAPi />
  )
}

export default App